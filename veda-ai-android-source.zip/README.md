# VEDA AI - Android App Source
Import this project into Android Studio, or push it to a GitHub repository to trigger the automatic APK build workflow.
