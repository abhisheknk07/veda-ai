package ai.veda.student

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    VedaAndroidApp()
                }
            }
        }
    }
}

@Composable
fun VedaAndroidApp() {
    var guestName by remember { mutableStateOf("") }
    var activeUser by remember { mutableStateOf<String?>(null) }
    var showNameDialog by remember { mutableStateOf(false) }

    if (activeUser == null) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("VEDA AI", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("Learn More. Create More. Build Anything.", fontSize = 14.sp)
            Spacer(modifier = Modifier.height(32.dp))

            if (!showNameDialog) {
                Button(onClick = { /* Google OAuth */ }, modifier = Modifier.fillMaxWidth()) { Text("Continue with Google") }
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick = { /* Email Auth */ }, modifier = Modifier.fillMaxWidth()) { Text("Continue with Email") }
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(onClick = { showNameDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("Continue as Guest") }
            } else {
                OutlinedTextField(
                    value = guestName,
                    onValueChange = { guestName = it },
                    label = { Text("Enter preferred name") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { if (guestName.isNotBlank()) activeUser = guestName.trim() },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Start Learning") }
            }
        }
    } else {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text("Welcome to VEDA, $activeUser!", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(12.dp))
            Text("Connected to VEDA Cloud Backend • Multi-Model Ready")
        }
    }
}